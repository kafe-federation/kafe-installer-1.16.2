<?php

$this->data['header'] = $this->t('{logout:title}');

$base_dir = dirname(__FILE__);
$base_dir = preg_replace('|/modules/.+|','/www',$base_dir);
include_once $base_dir.'/user_layout_head.php'; 

?>

<div class="login-kreonet">
<p class="login-error">
	<?php echo $this->data['header'] ?>
</p>

<div class="login-kreonet-form">
	<p class="area-text">
	<?php echo $this->t('{logout:logged_out_text}'); ?> 
	</p>
</div>

<?php include_once $base_dir.'/user_layout_footer.php'; ?>