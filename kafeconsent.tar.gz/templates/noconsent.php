<?php

if (array_key_exists('name', $this->data['dstMetadata'])) {
    $dstName = $this->data['dstMetadata']['name'];
} elseif (array_key_exists('OrganizationDisplayName', $this->data['dstMetadata'])) {
    $dstName = $this->data['dstMetadata']['OrganizationDisplayName'];
} else {
    $dstName = $this->data['dstMetadata']['entityid'];
}
if (is_array($dstName)) {
    $dstName = $this->t($dstName);
}
$dstName = htmlspecialchars($dstName);

$this->data['header'] = $this->t('{consent:consent:noconsent_title}');

$base_dir = dirname(__FILE__);
$base_dir = preg_replace('|/modules/.+|','/www',$base_dir);
include_once $base_dir.'/user_layout_head.php'; 
?>

<div class="login-kreonet">
<p class="login-error">
	<strong></strong>
	No consent given
</p>

<div class="login-kreonet-form">
	<span class="icon-warning"><?php echo $this->data['header'] ?></span>
	<span class="area-text"><?php echo  $this->t('{consent:consent:noconsent_text}', array('SPNAME' => '<br />'.$dstName)); ?></span>
	
	<p class="area-text">

		<?php if ($this->data['resumeFrom']) { ?>
		<a href="<?php echo htmlspecialchars($this->data['resumeFrom']) ?>" class="btn-navylight"><span class="icon-newlink"><?php echo $this->t('{consent:consent:noconsent_return}') ?></span></a>
		<?php } ?>

		<?php if ($this->data['aboutService']) { ?>
		<a href="<?php echo htmlspecialchars($this->data['aboutService']) ?>" class="btn-navylight"><span class="icon-newlink"><?php echo $this->t('{consent:consent:noconsent_goto_about}') ?></span></a>
		<?php } ?>
	
		<a href="<?php echo htmlspecialchars($this->data['logoutLink']) ?>" class="btn-navy"><span class="icon-newlink"><?php echo $this->t('{consent:consent:abort}', array('SPNAME' => $dstName)) ?></span></a>
	</p>	

</div>

<?php include_once $base_dir.'/user_layout_footer.php'; ?>