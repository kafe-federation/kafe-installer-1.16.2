		<!-- layout-footer -->
		<div id="layout-footer">
			<div id="footer">
				<p id="copyright">Copyright &copy; 2015- KREONET/KISTI. All Right Reserved. KAFE trademark and brand are the property of KREONET/KISTI.</p>
			</div>
		</div>		
		<!-- //layout-footer -->
	</div>
</body>
</html>
